import { TestBed } from '@angular/core/testing';

import { SidenavFixedExampleService } from './sidenav-fixed-example.service';

describe('SidenavFixedExampleService', () => {
  let service: SidenavFixedExampleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SidenavFixedExampleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { dateList } from './datesList.model';

@Injectable({
  providedIn: 'root'
})
export class SidenavFixedExampleService {

  constructor(private http:HttpClient) { }


  getList(){

    return this.http.get<dateList[]>("/someRandomEndPonit")
  }
}

import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import {dateList, ToDo} from '../datesList.model'
@Component({
  selector: 'date-card-compoenent',
  templateUrl: './date-card.component.html',
  styleUrls: ['./date-card.component.scss']
})
export class DateCardComponent implements OnInit {
 
  @Input() dateL: dateList;
  @Output() todoList = new EventEmitter<dateList>();

  constructor() { }

  ngOnInit(): void {
  }

  updateToDoList(list:dateList){
    console.log(list)
    this.todoList.emit(list)
  }


}

import { Component, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { dateList, ToDo } from "./datesList.model";
import { SidenavFixedExampleService } from "./sidenav-fixed-example.service";
import { MatSlideToggle } from "@angular/material/slide-toggle";
/** @title Fixed sidenav */
@Component({
  selector: "sidenav-fixed-example",
  templateUrl: "sidenav-fixed-example.html",
  styleUrls: ["sidenav-fixed-example.css"],
})
export class SidenavFixedExample {
  @ViewChild("drawer", { static: false }) togglebar: MatSlideToggle;
  tempTodos: ToDo;
  selectedDate:String;
  dateList: dateList[];
  tempList: ToDo[];
  currentIndex: number;
  constructor(private service: SidenavFixedExampleService) {}

  ngOnInit() {
    //   this.service.getList().subscribe((response: dateList[])=>{
    //    this.dateList = response
    //  },(err)=>{

    //   //customErrorHandler()
    //   //intimateErrorToUser()
    //   //IntimateErrorToBackendTeam()
    //  })

    //mocking the data
    this.dateList = [
      {
        currentDate: "13-July-2020",
        availableTodos: [
          { id: 1, title: "I am super human" },
          { id: 2, title: "I am batman" },
          { id: 3, title: "Sunna panaa" },
        ],
      },
      {
        currentDate: "14-July-2020",
        availableTodos: [
          { id: 1, title: "I am super human" },
          { id: 2, title: "I am batman" },
          { id: 3, title: "Sunna panaa" },
        ],
      },
      {
        currentDate: "15-July-2020",
        availableTodos: [
          { id: 1, title: "I am super human" },
          { id: 2, title: "I am batman" },
          { id: 3, title: "Sunna panaa" },
        ],
      },
      {
        currentDate: "16-July-2020",
        availableTodos: [
          { id: 1, title: "I am super human" },
          { id: 2, title: "I am batman" },
          { id: 3, title: "Sunna panaa" },
        ],
      },
    ];
  }
  updateListIn(event: dateList) {
    this.togglebar.toggle();
    this.selectedDate = event.currentDate;
    this.tempList = event.availableTodos;
    this.currentIndex= this.dateList.findIndex(x=>x.currentDate==this.selectedDate)
  }
  deleteTodo(id:number){
    this.dateList[this.currentIndex].availableTodos.splice(this.dateList[this.currentIndex].availableTodos.findIndex(x=>x.id==id),1)
   
  }
  pushValueInToDoList(value:string){
    if(!value){
      alert("enter a value or get out of here")
      return;
    }
    console.log(value)


      let id= this.tempList[this.tempList.length-1]?.id+1;
      let title = value;
      this.dateList[this.currentIndex].availableTodos.push({id,title})
     

    

  }
}

/**  Copyright 2020 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */

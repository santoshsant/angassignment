export interface ToDo {

    id : number,
    title:String;
}

export  interface dateList {
    currentDate : String,
    availableTodos: ToDo[];
}



